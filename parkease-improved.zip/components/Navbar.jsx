"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Menu, X } from "lucide-react"
import ThemeToggle from "./ThemeToggle"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const router = useRouter()

  const handleSmoothScroll = (sectionId) => {
    if (window.location.pathname !== "/") {
      router.push("/")
      setTimeout(() => {
        scrollToSection(sectionId)
      }, 100)
    } else {
      scrollToSection(sectionId)
    }
    setIsMenuOpen(false)
  }

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  }

  return (
    <nav className="fixed top-0 w-full bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="text-2xl font-bold text-black dark:text-white">
            ParkEase
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => handleSmoothScroll("home")}
              className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => handleSmoothScroll("features")}
              className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
            >
              Features
            </button>
            <button
              onClick={() => handleSmoothScroll("about")}
              className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
            >
              About
            </button>
            <button
              onClick={() => handleSmoothScroll("how-it-works")}
              className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
            >
              How It Works
            </button>
            <button
              onClick={() => handleSmoothScroll("testimonials")}
              className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
            >
              Testimonials
            </button>
            <button
              onClick={() => handleSmoothScroll("contact")}
              className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
            >
              Contact
            </button>
            <Link
              href="/login"
              className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
            >
              Login
            </Link>
            <Link
              href="/signup"
              className="bg-black dark:bg-white text-white dark:text-black px-4 py-2 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors"
            >
              Signup
            </Link>
            <ThemeToggle />
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center space-x-4">
            <ThemeToggle />
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-black dark:text-white">
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex flex-col space-y-4">
              <button
                onClick={() => handleSmoothScroll("home")}
                className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors text-left"
              >
                Home
              </button>
              <button
                onClick={() => handleSmoothScroll("features")}
                className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors text-left"
              >
                Features
              </button>
              <button
                onClick={() => handleSmoothScroll("about")}
                className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors text-left"
              >
                About
              </button>
              <button
                onClick={() => handleSmoothScroll("how-it-works")}
                className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors text-left"
              >
                How It Works
              </button>
              <button
                onClick={() => handleSmoothScroll("testimonials")}
                className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors text-left"
              >
                Testimonials
              </button>
              <button
                onClick={() => handleSmoothScroll("contact")}
                className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors text-left"
              >
                Contact
              </button>
              <Link
                href="/login"
                className="text-black dark:text-white hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
              >
                Login
              </Link>
              <Link
                href="/signup"
                className="bg-black dark:bg-white text-white dark:text-black px-4 py-2 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors inline-block text-center"
              >
                Signup
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
