"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarInset,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { Users, Calendar, Settings, BarChart3, Plus, Trash2 } from "lucide-react"

interface User {
  id: number
  name: string
  email: string
  whatsapp: string
  carNumber: string
  joinDate: string
}

// Update the interface for Booking to include paymentMethod
interface Booking {
  id: number
  userId: number
  userName: string
  slot: string
  hours: number
  date: string
  carNumber: string
  totalAmount: number
  status: string
  bookingDate: string
  paymentMethod?: string
}

interface Slot {
  id: string
  available: boolean
}

export default function AdminDashboard() {
  const router = useRouter()
  const [activeSection, setActiveSection] = useState("overview")
  const [users, setUsers] = useState<User[]>([])
  const [bookings, setBookings] = useState<Booking[]>([])
  const [slots, setSlots] = useState<Slot[]>([])
  const [showAddUserForm, setShowAddUserForm] = useState(false)
  const [showAddBookingForm, setShowAddBookingForm] = useState(false)
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    whatsapp: "",
    carNumber: "",
  })
  const [newBooking, setNewBooking] = useState({
    userId: "",
    slot: "",
    hours: "",
    date: "",
    carNumber: "",
    paymentMethod: "cash",
  })

  // Add state for editing bookings
  const [editingBooking, setEditingBooking] = useState<Booking | null>(null)
  const [showEditBookingForm, setShowEditBookingForm] = useState(false)

  const PRICE_PER_HOUR = 100

  const [userSearch, setUserSearch] = useState("")
  const [bookingSearch, setBookingSearch] = useState("")
  const [showBookingDetails, setShowBookingDetails] = useState(false)
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null)

  useEffect(() => {
    // Initialize slots (A1 to A80)
    const initialSlots = []
    for (let i = 1; i <= 80; i++) {
      initialSlots.push({
        id: `A${i}`,
        available: Math.random() > 0.3,
      })
    }
    setSlots(initialSlots)

    // Load demo users
    const demoUsers = [
      {
        id: 1,
        name: "John Doe",
        email: "john@example.com",
        whatsapp: "+92300123456",
        carNumber: "ABC-123",
        joinDate: "2024-01-15",
      },
      {
        id: 2,
        name: "Sarah Ahmed",
        email: "sarah@example.com",
        whatsapp: "+92301234567",
        carNumber: "XYZ-789",
        joinDate: "2024-01-20",
      },
      {
        id: 3,
        name: "Muhammad Ali",
        email: "ali@example.com",
        whatsapp: "+92302345678",
        carNumber: "DEF-456",
        joinDate: "2024-01-25",
      },
    ]
    setUsers(demoUsers)

    // Load demo bookings
    const demoBookings = [
      {
        id: 1001,
        userId: 1,
        userName: "John Doe",
        slot: "A15",
        hours: 3,
        date: "2024-01-30",
        carNumber: "ABC-123",
        totalAmount: 300,
        status: "Active",
        bookingDate: "2024-01-29",
        paymentMethod: "cash",
      },
      {
        id: 1002,
        userId: 2,
        userName: "Sarah Ahmed",
        slot: "A22",
        hours: 2,
        date: "2024-01-30",
        carNumber: "XYZ-789",
        totalAmount: 200,
        status: "Active",
        bookingDate: "2024-01-29",
        paymentMethod: "card",
      },
    ]
    setBookings(demoBookings)
  }, [])

  const handleLogout = () => {
    router.push("/")
  }

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault()
    const user = {
      id: Date.now(),
      ...newUser,
      joinDate: new Date().toISOString().split("T")[0],
    }
    setUsers((prev) => [...prev, user])
    setNewUser({ name: "", email: "", whatsapp: "", carNumber: "" })
    setShowAddUserForm(false)
    alert("User added successfully!")
  }

  const handleDeleteUser = (userId: number) => {
    if (window.confirm("Are you sure you want to delete this user?")) {
      setUsers((prev) => prev.filter((user) => user.id !== userId))
      setBookings((prev) => prev.filter((booking) => booking.userId !== userId))
      alert("User deleted successfully!")
    }
  }

  // Add function to handle editing bookings
  const handleEditBooking = (booking: Booking) => {
    setEditingBooking(booking)
    setShowEditBookingForm(true)
  }

  // Add function to save edited booking
  const saveEditedBooking = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingBooking) return

    // Validate hours (1-10)
    const hours = Number.parseInt(editingBooking.hours.toString())
    if (hours < 1 || hours > 10) {
      alert("Booking hours must be between 1 and 10")
      return
    }

    setBookings((prev) =>
      prev.map((booking) =>
        booking.id === editingBooking.id
          ? {
              ...editingBooking,
              totalAmount: Number.parseInt(editingBooking.hours.toString()) * PRICE_PER_HOUR,
            }
          : booking,
      ),
    )

    setShowEditBookingForm(false)
    setEditingBooking(null)
    alert("Booking updated successfully!")
  }

  // Add function to delete booking
  const handleDeleteBooking = (bookingId: number) => {
    if (window.confirm("Are you sure you want to delete this booking?")) {
      setBookings((prev) => prev.filter((booking) => booking.id !== bookingId))
      alert("Booking deleted successfully!")
    }
  }

  const viewBookingDetails = (booking: Booking) => {
    setSelectedBooking(booking)
    setShowBookingDetails(true)
  }

  const downloadBookingPDF = () => {
    alert("PDF receipt download started!")
  }

  // Update the handleAddBooking function
  const handleAddBooking = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate hours (1-10)
    const hours = Number.parseInt(newBooking.hours)
    if (hours < 1 || hours > 10) {
      alert("Booking hours must be between 1 and 10")
      return
    }

    const selectedUser = users.find((user) => user.id === Number.parseInt(newBooking.userId))
    if (!selectedUser) {
      alert("Please select a valid user")
      return
    }

    const booking = {
      id: Date.now(),
      ...newBooking,
      userId: Number.parseInt(newBooking.userId),
      userName: selectedUser.name,
      hours: Number.parseInt(newBooking.hours),
      totalAmount: Number.parseInt(newBooking.hours) * PRICE_PER_HOUR,
      status: "Active",
      bookingDate: new Date().toISOString().split("T")[0],
      paymentMethod: newBooking.paymentMethod, // Default to cash for admin bookings
    }

    setBookings((prev) => [...prev, booking])

    // Update slot availability
    setSlots((prev) => prev.map((slot) => (slot.id === newBooking.slot ? { ...slot, available: false } : slot)))

    setNewBooking({ userId: "", slot: "", hours: "", date: "", carNumber: "", paymentMethod: "cash" })
    setShowAddBookingForm(false)
    alert("Booking added successfully!")
  }

  const renderContent = () => {
    switch (activeSection) {
      // Update the overview section to show non-clickable slots
      case "overview":
        return (
          <div className="space-y-6">
            <h1 className="text-3xl font-bold text-black">Dashboard Overview</h1>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-lg shadow-md border">
                <h3 className="text-sm font-medium text-gray-600">Total Users</h3>
                <p className="text-3xl font-bold text-black">{users.length}</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md border">
                <h3 className="text-sm font-medium text-gray-600">Active Bookings</h3>
                <p className="text-3xl font-bold text-black">{bookings.filter((b) => b.status === "Active").length}</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md border">
                <h3 className="text-sm font-medium text-gray-600">Available Slots</h3>
                <p className="text-3xl font-bold text-black">{slots.filter((s) => s.available).length}</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md border">
                <h3 className="text-sm font-medium text-gray-600">Price Per Hour</h3>
                <p className="text-3xl font-bold text-black">Rs. {PRICE_PER_HOUR}</p>
              </div>
            </div>

            {/* Slots Grid - Non-clickable */}
            <div className="bg-white p-6 rounded-lg shadow-md border">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-black">Parking Slots (A1 - A80)</h2>
                <div className="flex space-x-4 text-sm">
                  <span className="flex items-center">
                    <div className="w-4 h-4 bg-green-200 border border-green-400 rounded mr-2"></div>
                    Available
                  </span>
                  <span className="flex items-center">
                    <div className="w-4 h-4 bg-red-200 border border-red-400 rounded mr-2"></div>
                    Occupied
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-10 gap-2">
                {slots.slice(0, 40).map((slot) => (
                  <div
                    key={slot.id}
                    className={`aspect-square flex items-center justify-center text-xs font-semibold rounded ${
                      slot.available
                        ? "bg-green-200 border border-green-400 text-green-800"
                        : "bg-red-200 border border-red-400 text-red-800"
                    }`}
                  >
                    {slot.id}
                  </div>
                ))}
              </div>
              <p className="text-sm text-gray-600 mt-2">Showing first 40 slots.</p>
            </div>
          </div>
        )

      case "users":
        const filteredUsers = users.filter(
          (user) =>
            user.name.toLowerCase().includes(userSearch.toLowerCase()) ||
            user.email.toLowerCase().includes(userSearch.toLowerCase()) ||
            user.carNumber.toLowerCase().includes(userSearch.toLowerCase()),
        )

        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center gap-4">
              <h1 className="text-3xl font-bold text-black">Users Management</h1>
              <button
                onClick={() => setShowAddUserForm(true)}
                className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors flex items-center space-x-2"
              >
                <Plus className="w-4 h-4" />
                <span>Add User</span>
              </button>
            </div>

            <div className="bg-white p-4 rounded-lg shadow-md border">
              <input
                type="text"
                placeholder="Search users by name, email, or car number..."
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg text-black"
              />
            </div>

            <div className="bg-white rounded-lg shadow-md border">
              <div className="p-6">
                <div className="space-y-4">
                  {filteredUsers.map((user) => (
                    <div key={user.id} className="flex justify-between items-center p-4 border rounded-lg">
                      <div>
                        <h3 className="font-semibold text-black">{user.name}</h3>
                        <p className="text-gray-600">Email: {user.email}</p>
                        <p className="text-gray-600">WhatsApp: {user.whatsapp}</p>
                        <p className="text-gray-600">Car: {user.carNumber}</p>
                        <p className="text-gray-600">Joined: {user.joinDate}</p>
                      </div>
                      <button
                        onClick={() => handleDeleteUser(user.id)}
                        className="bg-red-500 text-white px-3 py-2 rounded hover:bg-red-600 transition-colors flex items-center space-x-1"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span>Delete</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )

      // Update the bookings section to include edit and delete options
      case "bookings":
        const filteredBookings = bookings.filter(
          (booking) =>
            booking.userName.toLowerCase().includes(bookingSearch.toLowerCase()) ||
            booking.slot.toLowerCase().includes(bookingSearch.toLowerCase()) ||
            booking.carNumber.toLowerCase().includes(bookingSearch.toLowerCase()),
        )

        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center gap-4">
              <h1 className="text-3xl font-bold text-black">Bookings Management</h1>
              <button
                onClick={() => setShowAddBookingForm(true)}
                className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors flex items-center space-x-2"
              >
                <Plus className="w-4 h-4" />
                <span>Add Booking</span>
              </button>
            </div>

            <div className="bg-white p-4 rounded-lg shadow-md border">
              <input
                type="text"
                placeholder="Search bookings by user, slot, or car number..."
                value={bookingSearch}
                onChange={(e) => setBookingSearch(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg text-black"
              />
            </div>

            <div className="bg-white rounded-lg shadow-md border">
              <div className="p-6">
                <div className="space-y-4">
                  {filteredBookings.map((booking) => (
                    <div key={booking.id} className="flex justify-between items-center p-4 border rounded-lg">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 flex-1">
                        <div>
                          <p className="text-sm text-gray-600">ID: {booking.id}</p>
                          <p className="text-sm text-gray-600">User: {booking.userName}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Slot: {booking.slot}</p>
                          <p className="text-sm text-gray-600">Date: {booking.date}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Hours: {booking.hours}</p>
                          <p className="text-sm text-gray-600">Car: {booking.carNumber}</p>
                        </div>
                        <div>
                          <span
                            className={`inline-block px-2 py-1 rounded text-xs font-semibold ${
                              booking.status === "Active" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {booking.status}
                          </span>
                          <p className="text-sm font-semibold text-black">Rs. {booking.totalAmount}</p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => viewBookingDetails(booking)}
                          className="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600 transition-colors text-sm"
                        >
                          View
                        </button>
                        <button
                          onClick={() => handleEditBooking(booking)}
                          className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 transition-colors text-sm"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDeleteBooking(booking.id)}
                          className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 transition-colors text-sm"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )

      default:
        return <div>Select a section from the sidebar</div>
    }
  }

  const getTodayDate = () => {
    const today = new Date()
    const year = today.getFullYear()
    let month = (today.getMonth() + 1).toString()
    let day = today.getDate().toString()

    if (month.length < 2) {
      month = "0" + month
    }
    if (day.length < 2) {
      day = "0" + day
    }

    return [year, month, day].join("-")
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar className="border-r border-gray-200">
          <SidebarHeader className="p-4 border-b border-gray-200">
            <h2 className="text-xl font-bold text-black">Admin Panel</h2>
          </SidebarHeader>
          <SidebarContent className="p-4">
            {/* Update the sidebar menu to remove the Parking Slot option */}
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => setActiveSection("overview")}
                  isActive={activeSection === "overview"}
                  className="w-full justify-start text-black hover:bg-gray-100"
                >
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Overview
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => setActiveSection("users")}
                  isActive={activeSection === "users"}
                  className="w-full justify-start text-black hover:bg-gray-100"
                >
                  <Users className="w-4 h-4 mr-2" />
                  Users
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => setActiveSection("bookings")}
                  isActive={activeSection === "bookings"}
                  className="w-full justify-start text-black hover:bg-gray-100"
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Bookings
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton onClick={handleLogout} className="w-full justify-start text-red-600 hover:bg-red-50">
                  <Settings className="w-4 h-4 mr-2" />
                  Logout
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarContent>
        </Sidebar>

        <SidebarInset className="flex-1">
          <header className="flex h-16 items-center gap-2 border-b border-gray-200 px-6 bg-white">
            <SidebarTrigger />
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-semibold text-black">Admin Dashboard</h1>
            </div>
          </header>
          <main className="flex-1 p-6">{renderContent()}</main>
        </SidebarInset>
      </div>

      {/* Add User Modal */}
      {showAddUserForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
            <h2 className="text-xl font-bold text-black mb-4">Add New User</h2>
            <form onSubmit={handleAddUser} className="space-y-4">
              <input
                type="text"
                placeholder="Name"
                value={newUser.name}
                onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                required
              />
              <input
                type="email"
                placeholder="Email"
                value={newUser.email}
                onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                required
              />
              <input
                type="tel"
                placeholder="WhatsApp"
                value={newUser.whatsapp}
                onChange={(e) => setNewUser({ ...newUser, whatsapp: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded text-black"
              />
              <input
                type="text"
                placeholder="Car Number"
                value={newUser.carNumber}
                onChange={(e) => setNewUser({ ...newUser, carNumber: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded text-black"
              />
              <div className="flex space-x-2">
                <button type="submit" className="flex-1 bg-black text-white py-2 rounded hover:bg-gray-800">
                  Add User
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddUserForm(false)}
                  className="flex-1 bg-gray-300 text-black py-2 rounded hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Edit Booking Modal */}
      {showEditBookingForm && editingBooking && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
            <h2 className="text-xl font-bold text-black mb-4">Edit Booking</h2>
            <form onSubmit={saveEditedBooking} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-black mb-2">Slot</label>
                <input
                  type="text"
                  value={editingBooking.slot}
                  onChange={(e) => setEditingBooking({ ...editingBooking, slot: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-black mb-2">Hours (1-10)</label>
                <input
                  type="number"
                  value={editingBooking.hours}
                  onChange={(e) => setEditingBooking({ ...editingBooking, hours: Number.parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  min="1"
                  max="10"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-black mb-2">Date</label>
                <input
                  type="date"
                  value={editingBooking.date}
                  onChange={(e) => setEditingBooking({ ...editingBooking, date: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-black mb-2">Car Number</label>
                <input
                  type="text"
                  value={editingBooking.carNumber}
                  onChange={(e) => setEditingBooking({ ...editingBooking, carNumber: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-black mb-2">Status</label>
                <select
                  value={editingBooking.status}
                  onChange={(e) => setEditingBooking({ ...editingBooking, status: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                >
                  <option value="Active">Active</option>
                  <option value="Completed">Completed</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>
              <div className="flex space-x-2">
                <button type="submit" className="flex-1 bg-black text-white py-2 rounded hover:bg-gray-800">
                  Save Changes
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowEditBookingForm(false)
                    setEditingBooking(null)
                  }}
                  className="flex-1 bg-gray-300 text-black py-2 rounded hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Update Add Booking Modal to limit hours to 1-10 */}
      {showAddBookingForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
            <h2 className="text-xl font-bold text-black mb-4">Add Manual Booking</h2>
            <form onSubmit={handleAddBooking} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-black mb-2">Select User *</label>
                <select
                  name="userId"
                  value={newBooking.userId}
                  onChange={(e) => setNewBooking({ ...newBooking, userId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  required
                >
                  <option value="">Choose a user</option>
                  {users.map((user) => (
                    <option key={user.id} value={user.id}>
                      {user.name} - {user.email}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-black mb-2">Select Slot *</label>
                <select
                  name="slot"
                  value={newBooking.slot}
                  onChange={(e) => setNewBooking({ ...newBooking, slot: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  required
                >
                  <option value="">Choose a slot</option>
                  {slots
                    .filter((slot) => slot.available)
                    .map((slot) => (
                      <option key={slot.id} value={slot.id}>
                        {slot.id}
                      </option>
                    ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-black mb-2">Hours * (1-10)</label>
                <input
                  type="number"
                  name="hours"
                  value={newBooking.hours}
                  onChange={(e) => setNewBooking({ ...newBooking, hours: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  min="1"
                  max="10"
                  required
                />
                <small className="text-gray-600">
                  Total: Rs. {(Number.parseInt(newBooking.hours) || 0) * PRICE_PER_HOUR} (Maximum 10 hours)
                </small>
              </div>
              <div>
                <label className="block text-sm font-medium text-black mb-2">Date *</label>
                <input
                  type="date"
                  name="date"
                  value={newBooking.date}
                  onChange={(e) => setNewBooking({ ...newBooking, date: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  min={getTodayDate()}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-black mb-2">Car Number</label>
                <input
                  type="text"
                  name="carNumber"
                  value={newBooking.carNumber}
                  onChange={(e) => setNewBooking({ ...newBooking, carNumber: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-black mb-2">Payment Method</label>
                <div className="flex space-x-4">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="cash"
                      checked={newBooking.paymentMethod === "cash"}
                      onChange={(e) => setNewBooking({ ...newBooking, paymentMethod: e.target.value })}
                      className="mr-2"
                    />
                    Cash
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="jazzcash"
                      checked={newBooking.paymentMethod === "jazzcash"}
                      onChange={(e) => setNewBooking({ ...newBooking, paymentMethod: e.target.value })}
                      className="mr-2"
                    />
                    JazzCash
                  </label>
                </div>
              </div>
              <div className="flex space-x-2">
                <button type="submit" className="flex-1 bg-black text-white py-2 rounded hover:bg-gray-800">
                  Add Booking
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddBookingForm(false)}
                  className="flex-1 bg-gray-300 text-black py-2 rounded hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Booking Details Modal */}
      {showBookingDetails && selectedBooking && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-lg w-full mx-4 max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-black mb-4">Booking Details</h2>

            <div className="space-y-4 mb-6">
              <div>
                <h3 className="font-semibold text-black mb-2">Booking Information</h3>
                <div className="space-y-1 text-sm">
                  <p className="text-gray-700">
                    <strong>Booking ID:</strong> {selectedBooking.id}
                  </p>
                  <p className="text-gray-700">
                    <strong>User:</strong> {selectedBooking.userName}
                  </p>
                  <p className="text-gray-700">
                    <strong>Slot:</strong> {selectedBooking.slot}
                  </p>
                  <p className="text-gray-700">
                    <strong>Date:</strong> {selectedBooking.date}
                  </p>
                  <p className="text-gray-700">
                    <strong>Hours:</strong> {selectedBooking.hours}
                  </p>
                  <p className="text-gray-700">
                    <strong>Car Number:</strong> {selectedBooking.carNumber}
                  </p>
                  <p className="text-gray-700">
                    <strong>Payment Method:</strong>{" "}
                    {selectedBooking.paymentMethod === "jazzcash" ? "JazzCash" : "Cash"}
                  </p>
                  <p className="text-gray-700">
                    <strong>Total Amount:</strong> Rs. {selectedBooking.totalAmount}
                  </p>
                  <p className="text-gray-700">
                    <strong>Status:</strong> {selectedBooking.status}
                  </p>
                </div>
              </div>

              <div className="text-center">
                <h4 className="font-semibold text-black mb-2">QR Code</h4>
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=Booking-${selectedBooking.id}`}
                  alt="Booking QR Code"
                  className="mx-auto border rounded"
                />
              </div>

              <button
                onClick={downloadBookingPDF}
                className="w-full bg-black text-white py-2 px-4 rounded hover:bg-gray-800"
              >
                Download PDF
              </button>
            </div>

            <button
              onClick={() => setShowBookingDetails(false)}
              className="w-full bg-gray-300 text-black py-2 rounded hover:bg-gray-400"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </SidebarProvider>
  )
}
