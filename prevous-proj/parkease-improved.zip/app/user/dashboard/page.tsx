"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarInset,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { Car, Calendar, User, LogOut, Plus } from "lucide-react"

interface UserData {
  id: number
  name: string
  email: string
  whatsapp: string
  carNumber: string
}

interface Booking {
  id: number
  slot: string
  hours: string
  carNumber: string
  date: string
  whatsapp: string
  totalAmount: number
  bookingDate: string
  status: string
  paymentMethod: string
}

interface Slot {
  id: string
  available: boolean
}

export default function UserDashboard() {
  const router = useRouter()
  const [activeSection, setActiveSection] = useState("overview")
  const [userData, setUserData] = useState<UserData | null>(null)
  const [showBookingForm, setShowBookingForm] = useState(false)
  const [showReceipt, setShowReceipt] = useState(false)
  const [bookings, setBookings] = useState<Booking[]>([])
  const [availableSlots, setAvailableSlots] = useState<Slot[]>([])
  const [bookingForm, setBookingForm] = useState({
    slot: "",
    hours: "",
    carNumber: "",
    date: "",
    whatsapp: "",
    paymentMethod: "cash", // Default to cash
  })
  const [currentBooking, setCurrentBooking] = useState<Booking | null>(null)
  const [showJazzCashRedirect, setShowJazzCashRedirect] = useState(false)

  useEffect(() => {
    const storedUser = localStorage.getItem("currentUser")
    if (storedUser) {
      const user = JSON.parse(storedUser)
      setUserData(user)
      setBookingForm((prev) => ({
        ...prev,
        carNumber: user.carNumber || "",
        whatsapp: user.whatsapp || "",
        paymentMethod: "cash",
      }))
    }

    // Initialize available slots
    const slots = []
    for (let i = 1; i <= 80; i++) {
      slots.push({
        id: `A${i}`,
        available: Math.random() > 0.3,
      })
    }
    setAvailableSlots(slots)

    // Load existing bookings
    const existingBookings = JSON.parse(localStorage.getItem("userBookings") || "[]")
    setBookings(existingBookings)
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("currentUser")
    router.push("/")
  }

  const handleBookingInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setBookingForm((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!bookingForm.slot || !bookingForm.hours || !bookingForm.date) {
      alert("Please fill in all required fields")
      return
    }

    // Validate hours (1-10)
    const hours = Number.parseInt(bookingForm.hours)
    if (hours < 1 || hours > 10) {
      alert("Booking hours must be between 1 and 10")
      return
    }

    // If payment method is JazzCash, show redirect screen
    if (bookingForm.paymentMethod === "jazzcash") {
      setShowJazzCashRedirect(true)
      return
    }

    // For cash payment, proceed with booking
    const newBooking = {
      id: Date.now(),
      ...bookingForm,
      totalAmount: Number.parseInt(bookingForm.hours) * 100,
      bookingDate: new Date().toISOString(),
      status: "Confirmed",
      paymentMethod: bookingForm.paymentMethod,
    }

    const updatedBookings = [...bookings, newBooking]
    setBookings(updatedBookings)
    localStorage.setItem("userBookings", JSON.stringify(updatedBookings))

    setAvailableSlots((prev) =>
      prev.map((slot) => (slot.id === bookingForm.slot ? { ...slot, available: false } : slot)),
    )

    setCurrentBooking(newBooking)
    setShowBookingForm(false)
    setShowReceipt(true)

    setBookingForm({
      slot: "",
      hours: "",
      carNumber: userData?.carNumber || "",
      date: "",
      whatsapp: userData?.whatsapp || "",
      paymentMethod: "cash",
    })
  }

  const handlePayment = (method: string) => {
    alert(`Payment via ${method} - Feature coming soon!`)
  }

  const generateQRCode = () => {
    return `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=Booking-${currentBooking?.id}`
  }

  const downloadReceipt = () => {
    if (!currentBooking) return

    // Create a simple receipt content
    const receiptContent = `
      PARKEASE BOOKING RECEIPT
      ========================
      
      Booking ID: ${currentBooking.id}
      Slot: ${currentBooking.slot}
      Date: ${currentBooking.date}
      Hours: ${currentBooking.hours}
      Car Number: ${currentBooking.carNumber}
      Payment Method: ${currentBooking.paymentMethod === "jazzcash" ? "JazzCash" : "Cash"}
      Total Amount: Rs. ${currentBooking.totalAmount}
      Status: ${currentBooking.status}
      
      Thank you for using ParkEase!
    `

    // Create and download the file
    const element = document.createElement("a")
    const file = new Blob([receiptContent], { type: "text/plain" })
    element.href = URL.createObjectURL(file)
    element.download = `ParkEase-Receipt-${currentBooking.id}.txt`
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  const sendWhatsAppConfirmation = () => {
    alert("WhatsApp confirmation sent successfully!")
  }

  const getTodayDate = () => {
    return new Date().toISOString().split("T")[0]
  }

  const handleJazzCashComplete = () => {
    const newBooking = {
      id: Date.now(),
      ...bookingForm,
      totalAmount: Number.parseInt(bookingForm.hours) * 100,
      bookingDate: new Date().toISOString(),
      status: "Confirmed",
      paymentMethod: "jazzcash",
    }

    const updatedBookings = [...bookings, newBooking]
    setBookings(updatedBookings)
    localStorage.setItem("userBookings", JSON.stringify(updatedBookings))

    setAvailableSlots((prev) =>
      prev.map((slot) => (slot.id === bookingForm.slot ? { ...slot, available: false } : slot)),
    )

    setCurrentBooking(newBooking)
    setShowJazzCashRedirect(false)
    setShowReceipt(true)

    setBookingForm({
      slot: "",
      hours: "",
      carNumber: userData?.carNumber || "",
      date: "",
      whatsapp: userData?.whatsapp || "",
      paymentMethod: "cash",
    })
  }

  const viewBookingDetails = (booking: Booking) => {
    setCurrentBooking(booking)
    setShowReceipt(true)
  }

  const renderContent = () => {
    switch (activeSection) {
      case "overview":
        return (
          <div className="space-y-6">
            <h1 className="text-3xl font-bold text-black">Welcome, {userData?.name || "User"}!</h1>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-lg shadow-md border">
                <h2 className="text-xl font-semibold text-black mb-4">Parking Overview</h2>
                <div className="flex justify-center space-x-8 mb-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">
                      {availableSlots.filter((slot) => slot.available).length}
                    </div>
                    <div className="text-sm text-gray-600">Available Slots</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-red-600">
                      {availableSlots.filter((slot) => !slot.available).length}
                    </div>
                    <div className="text-sm text-gray-600">Occupied Slots</div>
                  </div>
                </div>
                <button
                  onClick={() => setShowBookingForm(true)}
                  className="w-full bg-black text-white py-3 rounded-lg hover:bg-gray-800 transition-colors font-semibold"
                >
                  Book Now
                </button>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md border">
                <h3 className="text-lg font-semibold text-black mb-4">Available Parking Slots</h3>
                <div className="grid grid-cols-8 gap-1 mb-4">
                  {availableSlots.slice(0, 32).map((slot) => (
                    <div
                      key={slot.id}
                      className={`aspect-square flex items-center justify-center text-xs font-semibold rounded ${
                        slot.available
                          ? "bg-green-200 border border-green-400 text-green-800"
                          : "bg-red-200 border border-red-400 text-red-800"
                      }`}
                    >
                      {slot.id}
                    </div>
                  ))}
                </div>
                <p className="text-sm text-gray-600">
                  Showing first 32 slots. Total: {availableSlots.length} slots available.
                </p>
              </div>
            </div>
          </div>
        )

      case "bookings":
        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h1 className="text-3xl font-bold text-black">My Bookings</h1>
              <button
                onClick={() => setShowBookingForm(true)}
                className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors flex items-center space-x-2"
              >
                <Plus className="w-4 h-4" />
                <span>New Booking</span>
              </button>
            </div>

            {bookings.length === 0 ? (
              <div className="bg-white p-12 rounded-lg shadow-md border text-center">
                <Car className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-xl text-gray-600">No bookings found</p>
                <p className="text-gray-500 mb-6">Book your first parking slot!</p>
                <button
                  onClick={() => setShowBookingForm(true)}
                  className="bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors"
                >
                  Book Now
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {bookings.map((booking) => (
                  <div key={booking.id} className="bg-white p-6 rounded-lg shadow-md border">
                    <div className="flex justify-between items-center">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div>
                          <p className="text-sm text-gray-600">Slot</p>
                          <p className="font-semibold text-black">{booking.slot}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Date</p>
                          <p className="font-semibold text-black">{booking.date}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Hours</p>
                          <p className="font-semibold text-black">{booking.hours}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Car</p>
                          <p className="font-semibold text-black">{booking.carNumber}</p>
                        </div>
                      </div>
                      <div className="text-right flex flex-col items-end">
                        <span
                          className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${
                            booking.status === "Confirmed" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {booking.status}
                        </span>
                        <p className="text-xl font-bold text-black mt-2">Rs. {booking.totalAmount}</p>
                        <button
                          onClick={() => viewBookingDetails(booking)}
                          className="mt-2 bg-black text-white px-4 py-1 rounded hover:bg-gray-800 text-sm"
                        >
                          View
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )

      case "profile":
        return (
          <div className="space-y-6">
            <h1 className="text-3xl font-bold text-black">Profile</h1>
            <div className="bg-white p-6 rounded-lg shadow-md border max-w-2xl">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-600">Name</label>
                  <p className="text-lg text-black">{userData?.name}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600">Email</label>
                  <p className="text-lg text-black">{userData?.email}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600">WhatsApp</label>
                  <p className="text-lg text-black">{userData?.whatsapp}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600">Car Number</label>
                  <p className="text-lg text-black">{userData?.carNumber}</p>
                </div>
              </div>
            </div>
          </div>
        )

      default:
        return <div>Select a section from the sidebar</div>
    }
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar className="border-r border-gray-200">
          <SidebarHeader className="p-4 border-b border-gray-200">
            <h2 className="text-xl font-bold text-black">User Panel</h2>
          </SidebarHeader>
          <SidebarContent className="p-4">
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => setActiveSection("overview")}
                  isActive={activeSection === "overview"}
                  className="w-full justify-start text-black hover:bg-gray-100"
                >
                  <Car className="w-4 h-4 mr-2" />
                  Overview
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => setActiveSection("bookings")}
                  isActive={activeSection === "bookings"}
                  className="w-full justify-start text-black hover:bg-gray-100"
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  My Bookings
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => setActiveSection("profile")}
                  isActive={activeSection === "profile"}
                  className="w-full justify-start text-black hover:bg-gray-100"
                >
                  <User className="w-4 h-4 mr-2" />
                  Profile
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton onClick={handleLogout} className="w-full justify-start text-red-600 hover:bg-red-50">
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarContent>
        </Sidebar>

        <SidebarInset className="flex-1">
          <header className="flex h-16 items-center gap-2 border-b border-gray-200 px-6 bg-white">
            <SidebarTrigger />
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-semibold text-black">User Dashboard</h1>
            </div>
          </header>
          <main className="flex-1 p-6">{renderContent()}</main>
        </SidebarInset>
      </div>

      {showBookingForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4 max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-black mb-4">Book Parking Slot</h2>
            <form onSubmit={handleBookingSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-black mb-2">Select Slot *</label>
                <select
                  name="slot"
                  value={bookingForm.slot}
                  onChange={handleBookingInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  required
                >
                  <option value="">Choose a slot</option>
                  {availableSlots
                    .filter((slot) => slot.available)
                    .map((slot) => (
                      <option key={slot.id} value={slot.id}>
                        {slot.id}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-black mb-2">Hours * (1-10)</label>
                <input
                  type="number"
                  name="hours"
                  value={bookingForm.hours}
                  onChange={handleBookingInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  placeholder="Number of hours"
                  min="1"
                  max="10"
                  required
                />
                <small className="text-gray-600">Rate: Rs. 100 per hour (Maximum 10 hours)</small>
              </div>

              <div>
                <label className="block text-sm font-medium text-black mb-2">Date *</label>
                <input
                  type="date"
                  name="date"
                  value={bookingForm.date}
                  onChange={handleBookingInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  min={getTodayDate()}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-black mb-2">Car Number</label>
                <input
                  type="text"
                  name="carNumber"
                  value={bookingForm.carNumber}
                  onChange={handleBookingInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  placeholder="Enter car number"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-black mb-2">WhatsApp Number</label>
                <input
                  type="tel"
                  name="whatsapp"
                  value={bookingForm.whatsapp}
                  onChange={handleBookingInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-black"
                  placeholder="WhatsApp number for confirmation"
                />
              </div>

              {bookingForm.hours && (
                <div className="bg-gray-50 p-4 rounded border">
                  <p className="text-lg font-semibold text-black">
                    Total Amount: Rs. {(Number.parseInt(bookingForm.hours) || 0) * 100}
                  </p>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-black mb-2">Payment Method</label>
                <div className="flex space-x-4">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="cash"
                      checked={bookingForm.paymentMethod === "cash"}
                      onChange={(e) => setBookingForm({ ...bookingForm, paymentMethod: e.target.value })}
                      className="mr-2"
                    />
                    Cash
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="jazzcash"
                      checked={bookingForm.paymentMethod === "jazzcash"}
                      onChange={(e) => setBookingForm({ ...bookingForm, paymentMethod: e.target.value })}
                      className="mr-2"
                    />
                    JazzCash
                  </label>
                </div>
              </div>

              <div className="flex space-x-2">
                <button type="submit" className="flex-1 bg-black text-white py-2 rounded hover:bg-gray-800">
                  Confirm Booking
                </button>
                <button
                  type="button"
                  onClick={() => setShowBookingForm(false)}
                  className="flex-1 bg-gray-300 text-black py-2 rounded hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showJazzCashRedirect && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
            <h2 className="text-xl font-bold text-black mb-4">JazzCash Payment</h2>
            <div className="space-y-4">
              <p className="text-black">Please send payment to complete your booking:</p>
              <div className="bg-gray-50 p-4 rounded border">
                <p className="font-semibold text-black">
                  Amount: Rs. {(Number.parseInt(bookingForm.hours) || 0) * 100}
                </p>
                <p className="font-semibold text-black">JazzCash Number: 03343282332</p>
              </div>
              <p className="text-sm text-gray-600">
                After sending payment, click the "Payment Complete" button below to confirm your booking.
              </p>
              <div className="flex space-x-2">
                <button
                  onClick={handleJazzCashComplete}
                  className="flex-1 bg-black text-white py-2 rounded hover:bg-gray-800"
                >
                  Payment Complete
                </button>
                <button
                  onClick={() => setShowJazzCashRedirect(false)}
                  className="flex-1 bg-gray-300 text-black py-2 rounded hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showReceipt && currentBooking && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-lg w-full mx-4 max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-black mb-4">Booking Details</h2>

            <div className="space-y-4 mb-6">
              <div>
                <h3 className="font-semibold text-black mb-2">Booking Information</h3>
                <div className="space-y-1 text-sm">
                  <p className="text-gray-700">
                    <strong>Booking ID:</strong> {currentBooking.id}
                  </p>
                  <p className="text-gray-700">
                    <strong>Slot:</strong> {currentBooking.slot}
                  </p>
                  <p className="text-gray-700">
                    <strong>Date:</strong> {currentBooking.date}
                  </p>
                  <p className="text-gray-700">
                    <strong>Hours:</strong> {currentBooking.hours}
                  </p>
                  <p className="text-gray-700">
                    <strong>Car Number:</strong> {currentBooking.carNumber}
                  </p>
                  <p className="text-gray-700">
                    <strong>Payment Method:</strong> {currentBooking.paymentMethod === "jazzcash" ? "JazzCash" : "Cash"}
                  </p>
                  <p className="text-gray-700">
                    <strong>Total Amount:</strong> Rs. {currentBooking.totalAmount}
                  </p>
                </div>
              </div>

              <div className="text-center">
                <h4 className="font-semibold text-black mb-2">QR Code</h4>
                <img
                  src={generateQRCode() || "/placeholder.svg"}
                  alt="Booking QR Code"
                  className="mx-auto border rounded"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button onClick={downloadReceipt} className="bg-black text-white py-2 px-4 rounded hover:bg-gray-800">
                  Download PDF
                </button>
                <button
                  onClick={sendWhatsAppConfirmation}
                  className="bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700"
                >
                  Send WhatsApp
                </button>
              </div>
            </div>

            <button
              onClick={() => setShowReceipt(false)}
              className="w-full bg-gray-300 text-black py-2 rounded hover:bg-gray-400"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </SidebarProvider>
  )
}
